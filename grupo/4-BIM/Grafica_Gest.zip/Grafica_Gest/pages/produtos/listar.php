<?php
// Tela do sistema: apresentação dos dados e formulários.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
$products=rows('SELECT * FROM produtos ORDER BY nome');
if(in_array((int)$me['perfil'],[1,2])): $r=isset($_GET['edit'])?q('SELECT * FROM produtos WHERE id=?',[$_GET['edit']])->fetch():[];
 ?>
<section><h2>
<?= $r ? 'Editar produto' : 'Novo produto' ?></h2>
<?php
start('produto');
echo '<input type="hidden" name="id" value="'.h($r['id']??0).'">';
field('Nome','nome','text',$r['nome']??'');
echo '<label>Categoria<select name="categoria" required><option value="">Selecione uma categoria</option>';
foreach (rows('SELECT nome FROM categorias ORDER BY nome') as $cat) {
    echo '<option value="'.h($cat['nome']).'" '.(($r['categoria']??'')===$cat['nome']?'selected':'').'>'.h($cat['nome']).'</option>';
}
echo '</select></label><a class="category-link wide-field" href="?p=categorias">+ Criar categoria</a>';
echo '<label class="wide-field">Descrição<textarea name="descricao" rows="3">'.h($r['descricao']??'').'</textarea></label>'; 
field('Preço','preco','number',$r['preco']??'','required min="0" step="0.01"');
field('Estoque mínimo','minimo','number',$r['minimo']??5,'required min="1"');
endform();
 ?>
</section>

<?php
endif;
 ?>
<section><h2>Catálogo de produtos</h2><input id="search" placeholder="Buscar produto..." oninput="document.querySelectorAll('.product').forEach(x=>x.hidden=!x.innerText.toLowerCase().includes(this.value.toLowerCase()))">
<?php
foreach($products as $v)echo '<div class="line product"><div><b>'.h($v['nome']).'</b><small>'.h($v['categoria']).' · '.h($v['descricao']).'</small></div><div>'.money($v['preco']).' · '.$v['quantidade'].' un. '.((int)$v['quantidade'] < (int)$v['minimo']?'<span class="alert">Estoque baixo</span>':'<span class="pill">Disponível</span>').'</div>'.(in_array((int)$me['perfil'],[1,2])?'<a href="?p=produtos&edit='.$v['id'].'">Editar</a>':'').'</div>';
 ?>
</section>
