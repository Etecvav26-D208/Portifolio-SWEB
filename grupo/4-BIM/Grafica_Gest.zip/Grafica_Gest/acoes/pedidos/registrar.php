<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='pedido') {
    need([1,3]);
    if(!trim($_POST['descricao'])||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$_POST['prazo']))throw new Exception('Dados inválidos.');
    q('INSERT INTO pedidos(descricao,quantidade,valor,prazo,usuario) VALUES(?,?,?,?,?)',[trim($_POST['descricao']),positive($_POST['quantidade']),amount($_POST['valor']),$_POST['prazo'],$me['id']]);
}
