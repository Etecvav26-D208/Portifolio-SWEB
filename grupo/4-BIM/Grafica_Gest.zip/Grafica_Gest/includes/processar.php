<?php
// Componente compartilhado do sistema.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        if(!hash_equals($_SESSION['csrf'],$_POST['csrf']??''))throw new Exception('Sessão inválida.');
        $a=$_POST['a']??'';
        if (!in_array($a, ['setup','login','logout','usuario','produto','categoria','estoque','venda','pedido','status','editar_pedido'], true)) {
            throw new Exception('Operação inválida.');
        }
        if($a==='setup') require __DIR__.'/../acoes/acesso/configurar.php';
        if($a==='login') require __DIR__.'/../acoes/acesso/entrar.php';
        if(!$me)throw new Exception('Faça login.');
        if($a==='logout') {
            session_destroy();
            go();
        }
        if($a==='usuario') require __DIR__.'/../acoes/funcionarios/salvar.php';
        if($a==='categoria') require __DIR__.'/../acoes/categorias/salvar.php';
        if($a==='produto') require __DIR__.'/../acoes/produtos/salvar.php';
        if($a==='estoque') require __DIR__.'/../acoes/estoque/movimentar.php';
        if($a==='venda') require __DIR__.'/../acoes/vendas/registrar.php';
        if($a==='pedido') require __DIR__.'/../acoes/pedidos/registrar.php';
        if($a==='editar_pedido') require __DIR__.'/../acoes/pedidos/editar.php';
        if($a==='status') require __DIR__.'/../acoes/pedidos/atualizar.php';
        $_SESSION['flash']='Operação realizada com sucesso.';
        go(in_array($a,['pedido','status','editar_pedido'],true)?'pedidos':(isset($menus[$p])?$p:'inicio'));
    }
    catch(Throwable $e) {
        if($db->inTransaction())$db->rollBack();
        $error=$e instanceof PDOException?'Não foi possível salvar. Verifique os dados e se o login já existe.':$e->getMessage();
    }
}
