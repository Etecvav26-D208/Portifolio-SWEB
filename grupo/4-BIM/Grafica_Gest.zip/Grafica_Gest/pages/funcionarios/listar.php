<?php
// Tela do sistema: apresentação dos dados e formulários.
if(!defined('GRAFICA_APP'))exit;
require __DIR__.'/formulario.php';
 ?>
<section><h2>Equipe</h2>
<?php
foreach(rows('SELECT u.*,p.nome AS cargo FROM usuarios u JOIN perfis p ON p.id=u.perfil') as $r)echo '<div class="line"><div><b>'.h($r['nome']).'</b> · '.h($r['cargo']).' · '.($r['ativo']?'Ativo':'Bloqueado').'</div><a href="?p=funcionarios&edit='.$r['id'].'">Editar</a></div>';
 ?>
</section>
