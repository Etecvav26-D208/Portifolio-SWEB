<?php
// Configuração e entrada da aplicação.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
$host='localhost';
$usuario='root';
$senha='';
$banco='grafica_gest';
