<?php
if (!defined('GRAFICA_APP')) exit;
$statuses = ['Pendente','Em produção','Concluído','Entregue'];
$role = (int)$me['perfil'];
$canEdit = in_array($role,[1,2,3],true);
$canStatus = in_array($role,[1,2,4],true);
$counts = array_fill_keys($statuses,0);
foreach (rows('SELECT status, COUNT(*) AS total FROM pedidos GROUP BY status') as $item) {
    $counts[$item['status']] = (int)$item['total'];
}
$search = is_string($_GET['busca'] ?? null) ? trim($_GET['busca']) : '';
$status = is_string($_GET['situacao'] ?? null) ? $_GET['situacao'] : '';
$from = is_string($_GET['de'] ?? null) ? $_GET['de'] : '';
$to = is_string($_GET['ate'] ?? null) ? $_GET['ate'] : '';
$where = []; $params = [];
if ($search !== '') { $where[] = '(descricao LIKE ? OR CAST(id AS CHAR)=?)'; $params[] = '%'.$search.'%'; $params[] = ltrim($search,'#'); }
if (in_array($status,$statuses,true)) { $where[] = 'status=?'; $params[] = $status; }
foreach (['>='=>$from,'<='=>$to] as $op=>$date) {
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) { $where[] = 'DATE(data) '.$op.' ?'; $params[] = $date; }
}
$orders = rows('SELECT * FROM pedidos'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY id DESC',$params);
?>
<section class="orders-panel order-heading"><div><small>PRODUÇÃO / ENCOMENDAS</small><h2>Central de pedidos</h2><p>Acompanhe todos os serviços da gráfica.</p></div>
<?php if (in_array($role,[1,3],true)): ?><a class="order-button" href="?p=novo_pedido">+ Novo pedido</a><?php endif; ?></section>
<div class="order-metrics">
<?php foreach (['Total de pedidos'=>array_sum($counts)]+$counts as $label=>$count): ?>
<div class="order-metric"><small><?=h($label)?></small><strong><?=h($count)?></strong></div>
<?php endforeach; ?></div>
<section class="orders-panel"><h2>Todos os pedidos</h2>
<form method="get" class="order-filter"><input type="hidden" name="p" value="pedidos">
<label>Buscar<input name="busca" value="<?=h($search)?>" placeholder="Descrição ou número"></label>
<label>Status<select name="situacao"><option value="">Todos</option><?php foreach($statuses as $s): ?><option <?= $status===$s?'selected':'' ?>><?=h($s)?></option><?php endforeach; ?></select></label>
<label>De<input type="date" name="de" value="<?=h($from)?>"></label><label>Até<input type="date" name="ate" value="<?=h($to)?>"></label>
<button>Filtrar</button><a href="?p=pedidos">Limpar</a></form>
<p><?=count($orders)?> pedido(s) encontrado(s)</p>
<?php foreach($orders as $r): ?>
<article class="order-item"><div class="order-heading"><div><small>Pedido #<?=h($r['id'])?> · <?=h($r['data'])?></small><h3><?=h($r['descricao'])?></h3></div><span class="order-status status-<?=array_search($r['status'],$statuses,true)?>"><?=h($r['status'])?></span></div>
<div class="order-details"><span>Quantidade: <b><?=h($r['quantidade'])?></b></span><span>Valor: <b><?=money($r['valor'])?></b></span><span>Prazo: <b><?=h($r['prazo'])?></b></span></div>
<?php if($canEdit): ?><details><summary>Editar pedido</summary><?php start('editar_pedido'); ?><input type="hidden" name="id" value="<?=h($r['id'])?>"><label class="order-wide">Descrição<textarea name="descricao" required rows="3"><?=h($r['descricao'])?></textarea></label><?php field('Quantidade','quantidade','number',$r['quantidade'],'required min="1"'); field('Valor total','valor','number',$r['valor'],'required min="0" step="0.01"'); field('Prazo','prazo','date',$r['prazo']); endform('Salvar alterações'); ?></details><?php endif; ?>
<?php if($canStatus): start('status'); ?><input type="hidden" name="id" value="<?=h($r['id'])?>"><label>Andamento<select name="status"><?php foreach($statuses as $s): ?><option <?=$s===$r['status']?'selected':''?>><?=h($s)?></option><?php endforeach; ?></select></label><?php endform('Atualizar status'); endif; ?>
</article><?php endforeach; ?>
<?php if(!$orders): ?><p>Nenhum pedido encontrado.</p><?php endif; ?></section>
