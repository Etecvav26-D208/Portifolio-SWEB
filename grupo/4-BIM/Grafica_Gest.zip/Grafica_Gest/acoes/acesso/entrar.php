<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='login') {
    $u=q('SELECT * FROM usuarios WHERE login=? AND ativo=1',[$_POST['login']])->fetch();
    if(!$u||!password_verify($_POST['senha'],$u['senha']))throw new Exception('Usuário ou senha incorretos.');
    session_regenerate_id(true);
    $_SESSION['uid']=$u['id'];
    go();
}
