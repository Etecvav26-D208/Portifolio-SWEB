<?php
if (!defined('GRAFICA_APP')) exit;
need([1,2,3]);
$id = positive($_POST['id'] ?? null);
$descricao = trim($_POST['descricao'] ?? '');
$prazo = $_POST['prazo'] ?? '';
$data = DateTimeImmutable::createFromFormat('!Y-m-d', $prazo);
if (!$descricao || !$data || $data->format('Y-m-d') !== $prazo) {
    throw new Exception('Informe uma descrição e um prazo válido.');
}
if (!val('SELECT COUNT(*) FROM pedidos WHERE id=?', [$id])) {
    throw new Exception('Pedido não encontrado.');
}
q('UPDATE pedidos SET descricao=?, quantidade=?, valor=?, prazo=? WHERE id=?', [
    $descricao, positive($_POST['quantidade'] ?? null), amount($_POST['valor'] ?? null), $prazo, $id
]);
