<?php
// Componente compartilhado do sistema.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
function menuicon($k) {
    $paths=['inicio'=>'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>','funcionarios'=>'<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6m2 4a5 5 0 0 1 3 5v2"/>','produtos'=>'<path d="m3 7 9-4 9 4v10l-9 4-9-4zM3 7l9 5 9-5M12 12v9"/>','vendas'=>'<path d="M3 3h2l3 12h11l2-9H6"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>','pedidos'=>'<path d="M6 8V3h12v5M6 17H3V9h18v8h-3M6 14h12v7H6z"/>','relatorios'=>'<path d="M4 3v18h17M8 16v-4m5 4V7m5 9V4"/>'];
    return '<svg class="navicon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$k]??'<path d="M4 8h16M16 4l4 4-4 4M20 16H4m4-4-4 4 4 4"/>').'</svg>';
}
$descriptions=['funcionarios'=>'Gerencie a equipe e os acessos.','produtos'=>'Consulte o catálogo e as movimentações.','vendas'=>'Acompanhe as operações comerciais.','pedidos'=>'Organize os serviços de impressão.','relatorios'=>'Consulte resultados e exporte para a APM.'];
$p=$_GET['p']??'inicio';
if (!is_string($p)) { $p = 'inicio'; }
$menus=['inicio'=>'Visão geral','funcionarios'=>'Funcionários','produtos'=>'Produtos','estoque'=>'Estoque','movimentos'=>'Movimentações','vendas'=>'Vendas','pedidos'=>'Pedidos gráficos','relatorios'=>'Relatórios'];
$access=['inicio'=>[1,2,3,4],'funcionarios'=>[1],'produtos'=>[1,2,3],'estoque'=>[1,2,3],'movimentos'=>[1,2],'vendas'=>[2,3],'pedidos'=>[2,3,4],'relatorios'=>[2]];

$descriptions['estoque']='Confira os materiais e níveis de estoque.';
$descriptions['movimentos']='Registre entradas e saídas e consulte o histórico.';

$menus = array_slice($menus,0,3,true) + ["categorias"=>"Categorias"] + array_slice($menus,3,null,true);
$access["categorias"]=[1,2];
$descriptions["categorias"]="Organize os produtos por tipo.";
foreach ($access as &$roles) { if (!in_array(1,$roles,true)) $roles[] = 1; }
unset($roles);

// Cadastro separado da central de acompanhamento.
$menus['pedidos'] = 'Gerenciar pedidos';
$menus = array_slice($menus, 0, array_search('pedidos', array_keys($menus)), true) + ['novo_pedido'=>'Novo pedido'] + $menus;
$access['novo_pedido'] = [1,3];
$descriptions['novo_pedido'] = 'Registre uma nova encomenda.';
$descriptions['pedidos'] = 'Consulte e acompanhe todas as encomendas.';
