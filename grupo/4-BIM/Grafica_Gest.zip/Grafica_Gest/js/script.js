// Atualiza o total exibido. O PHP recalcula o valor ao salvar a venda.
function calc() {
    let total = 0;
    document.querySelectorAll('.cartrow').forEach(linha => {
        const preco = Number(linha.querySelector('select').selectedOptions[0]?.dataset.price || 0);
        const quantidade = Number(linha.querySelector('input').value || 0);
        total += preco * quantidade;
    });
    document.getElementById('total').textContent = total.toLocaleString('pt-BR', {
        style: 'currency', currency: 'BRL'
    });
}

// Adiciona uma nova linha de produto ao formulário.
function add() {
    const linha = document.querySelector('.cartrow').cloneNode(true);
    linha.querySelector('select').value = '';
    linha.querySelector('input').value = 1;
    document.getElementById('cart').append(linha);
    calc();
}
