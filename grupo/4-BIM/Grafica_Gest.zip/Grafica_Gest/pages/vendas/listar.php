<?php
// Tela do sistema: apresentação dos dados e formulários.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if(in_array((int)$me['perfil'],[1,3],true)): ?>
<section><h2>Nova venda</h2>
<?php
start('venda');
 ?>
<div id="cart"><div class="cartrow"><label>Produto<select name="produto[]" onchange="calc()"><option value="">Selecione</option>
<?php
foreach(rows('SELECT * FROM produtos WHERE quantidade>0') as $r)echo '<option value="'.$r['id'].'" data-price="'.$r['preco'].'">'.h($r['nome']).' — '.money($r['preco']).' ('.$r['quantidade'].' un.)</option>';
 ?>
</select></label><label>Quantidade<input type="number" name="quantidade[]" value="1" min="1" required oninput="calc()"></label></div></div><button type="button" class="secondary" onclick="add()">+ Adicionar item</button><h2 id="total">R$ 0,00</h2>
<?php
endform('Confirmar venda');
 ?>
</section>
<?php
endif;
 ?>
<section><h2>Histórico de vendas</h2>
<?php
$rs=rows('SELECT v.id,v.data,u.nome,v.total FROM vendas v JOIN usuarios u ON u.id=v.usuario '.($me['perfil']==3?'WHERE v.usuario=? ':'').'ORDER BY v.id DESC',$me['perfil']==3?[$me['id']]:[]);
foreach($rs as $r) {
    echo '<div class="line"><b>Venda #'.$r['id'].'</b>'.h($r['data']).' · '.h($r['nome']).' · '.money($r['total']).'</div>';
    table(['Produto','Quantidade','Preço unitário'],rows('SELECT p.nome,i.quantidade,i.preco FROM itens_venda i JOIN produtos p ON p.id=i.produto WHERE i.venda=?',[$r['id']]));
}
 ?>
</section>
