<?php
// Tela do sistema: apresentação dos dados e formulários.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
$u=isset($_GET['edit'])?q('SELECT * FROM usuarios WHERE id=?',[$_GET['edit']])->fetch():[];
 ?>
<section><h2>
<?= $u ? 'Editar funcionário' : 'Cadastrar funcionário' ?></h2>
<?php
start('usuario');
echo '<input type="hidden" name="id" value="'.h($u['id']??0).'">';
field('Nome','nome','text',$u['nome']??'');
field('Login','login','text',$u['login']??'');
field('Senha (mín. 8 caracteres)','senha','password','',$u?'':'required');
echo '<label>Perfil<select name="perfil">';
foreach(rows('SELECT * FROM perfis') as $r)echo '<option value="'.$r['id'].'" '.(($u['perfil']??0)==$r['id']?'selected':'').'>'.h($r['nome']).'</option>';
echo '</select></label><label class="check"><input type="checkbox" name="ativo" '.(($u['ativo']??1)?'checked':'').'> Conta ativa</label>';
endform();
 ?>
</section>
