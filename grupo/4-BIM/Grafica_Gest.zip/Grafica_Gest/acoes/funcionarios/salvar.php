<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='usuario') {
    need([1]);
    $id=(int)($_POST['id']??0);
    $role=positive($_POST['perfil']);
    if($role>4)throw new Exception('Perfil inválido.');
    $ativo=isset($_POST['ativo'])?1:0;
    if($id==$me['id']&&(!$ativo||$role!==1))throw new Exception('Não altere seu próprio acesso administrativo.');
    $data=[trim($_POST['nome']),trim($_POST['login']),$role,$ativo];
    if(!$data[0]||!$data[1])throw new Exception('Preencha os campos.');
    if($id) {
        // Valide a senha antes de modificar qualquer dado.
        if ($_POST['senha'] !== '' && strlen($_POST['senha']) < 8) {
            throw new Exception('Senha curta.');
        }
        $db->beginTransaction();
        q('UPDATE usuarios SET nome=?,login=?,perfil=?,ativo=? WHERE id=?',[...$data,$id]);
        if($_POST['senha']!=='') {
            if(strlen($_POST['senha'])<8)throw new Exception('Senha curta.');
            q('UPDATE usuarios SET senha=? WHERE id=?',[password_hash($_POST['senha'],PASSWORD_DEFAULT),$id]);
        }
        $db->commit();
    }
    else {
        if(strlen($_POST['senha'])<8)throw new Exception('Senha mínima de 8 caracteres.');
        q('INSERT INTO usuarios(nome,login,perfil,ativo,senha) VALUES(?,?,?,?,?)',[...$data,password_hash($_POST['senha'],PASSWORD_DEFAULT)]);
    }
}
