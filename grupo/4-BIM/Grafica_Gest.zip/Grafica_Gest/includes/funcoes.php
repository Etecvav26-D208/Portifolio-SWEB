<?php
// Componente compartilhado do sistema.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
function start($a) {
    echo '<form method="post"><input type="hidden" name="csrf" value="'.h($_SESSION['csrf']).'"><input type="hidden" name="a" value="'.h($a).'">';
}
function field($label,$name,$type='text',$value='',$extra='required') {
    echo '<label>'.h($label).'<input name="'.h($name).'" type="'.h($type).'" value="'.h($value).'" '.$extra.'></label>';
}
function endform($label='Salvar') {
    echo '<button>'.h($label).'</button></form>';
}
function table($heads,$data) {
    echo '<div class="tablewrap"><table><thead><tr>';
    foreach($heads as $v)echo '<th>'.h($v).'</th>';
    echo '</tr></thead><tbody>';
    foreach($data as $r) {
        echo '<tr>';
        foreach($r as $v)echo '<td>'.h($v).'</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}
