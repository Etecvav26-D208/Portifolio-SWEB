<?php
// Tela do sistema: apresentação dos dados e formulários.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
$from=$_GET['de']??date('Y-m-01');
$to=$_GET['ate']??date('Y-m-d');
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)||$from>$to) {
    $from=date('Y-m-01');
    $to=date('Y-m-d');
}
$range=[$from,$to];
 ?>
<section class="noprint"><h2>Selecionar período</h2><form method="get"><input type="hidden" name="p" value="relatorios">
<?php
field('De','de','date',$from);
field('Até','ate','date',$to);
endform('Consultar');
 ?>
</section><section class="report"><h2>Relatório gerencial · APM</h2><p>Período:
<?=h($from) ?>
a
<?=h($to) ?>
</p><h3>Vendas:
<?=money(val('SELECT COALESCE(SUM(total),0) FROM vendas WHERE DATE(data) BETWEEN ? AND ?',$range)) ?>
</h3>
<?php
table(['Data','Total'],rows('SELECT data,total FROM vendas WHERE DATE(data) BETWEEN ? AND ? ORDER BY data',$range));
 ?>
<h3>Pedidos por situação</h3>
<?php
table(['Situação','Quantidade'],rows('SELECT status,COUNT(*) FROM pedidos WHERE DATE(data) BETWEEN ? AND ? GROUP BY status',$range));
 ?>
<h3>Estoque atual (não histórico)</h3>
<?php
table(['Produto','Quantidade','Mínimo'],rows('SELECT nome,quantidade,minimo FROM produtos ORDER BY nome'));
 ?>
</section>
