<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if ($a === 'setup' && !$setup) {
    throw new Exception('Configuração inicial já realizada.');
}
if($a==='setup'&&$setup) {
    if (!trim($_POST['nome'] ?? '') || !trim($_POST['login'] ?? '')) {
        throw new Exception('Preencha nome e login.');
    }
    if(strlen($_POST['senha'])<8)throw new Exception('Use pelo menos 8 caracteres.');
    q('INSERT INTO usuarios(nome,login,senha,perfil) VALUES(?,?,?,1)',[trim($_POST['nome']),trim($_POST['login']),password_hash($_POST['senha'],PASSWORD_DEFAULT)]);
    go();
}
