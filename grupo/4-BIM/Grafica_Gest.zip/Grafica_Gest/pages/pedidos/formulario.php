<?php
if (!defined('GRAFICA_APP')) exit;
?>
<section class="orders-panel"><h2>Novo pedido gráfico</h2><p>Informe os detalhes da encomenda.</p>
<?php start('pedido'); ?>
<label class="order-wide">Descrição do serviço<textarea name="descricao" required rows="4"></textarea></label>
<?php
field('Quantidade','quantidade','number',1,'required min="1"');
field('Valor total previsto (R$)','valor','number','','required min="0" step="0.01"');
field('Prazo de entrega','prazo','date');
endform('Registrar pedido');
?>
<a href="?p=pedidos">← Voltar à central de pedidos</a></section>
