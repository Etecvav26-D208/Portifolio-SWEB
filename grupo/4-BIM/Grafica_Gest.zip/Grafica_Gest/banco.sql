CREATE DATABASE IF NOT EXISTS grafica_gest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE grafica_gest;
CREATE TABLE IF NOT EXISTS perfis(
    id INT PRIMARY KEY,
    nome VARCHAR(50)
);
INSERT IGNORE INTO perfis VALUES(1,'Administrador'),(2,'Gerente'),(3,'Atendente'),(4,'Operador de produção');
CREATE TABLE IF NOT EXISTS usuarios(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(60) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    perfil INT NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    FOREIGN KEY(perfil) REFERENCES perfis(id)
);
CREATE TABLE IF NOT EXISTS produtos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    categoria VARCHAR(100),
    descricao TEXT,
    preco DECIMAL(10,2) NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
    minimo INT NOT NULL DEFAULT 5
);
CREATE TABLE IF NOT EXISTS movimentacoes_estoque(
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto INT NOT NULL,
    usuario INT NOT NULL,
    tipo VARCHAR(10),
    quantidade INT,
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(produto) REFERENCES produtos(id),
    FOREIGN KEY(usuario) REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS vendas(
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario INT NOT NULL,
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(12,2),
    FOREIGN KEY(usuario) REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS itens_venda(
    id INT AUTO_INCREMENT PRIMARY KEY,
    venda INT,
    produto INT,
    quantidade INT,
    preco DECIMAL(10,2),
    FOREIGN KEY(venda) REFERENCES vendas(id),
    FOREIGN KEY(produto) REFERENCES produtos(id)
);
CREATE TABLE IF NOT EXISTS pedidos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricao TEXT NOT NULL,
    quantidade INT,
    valor DECIMAL(10,2),
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    prazo DATE,
    status VARCHAR(30) DEFAULT 'Pendente',
    usuario INT,
    FOREIGN KEY(usuario) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS categorias (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL UNIQUE
);
INSERT IGNORE INTO categorias(nome) SELECT DISTINCT TRIM(categoria) FROM produtos WHERE categoria IS NOT NULL AND TRIM(categoria) <> '';
