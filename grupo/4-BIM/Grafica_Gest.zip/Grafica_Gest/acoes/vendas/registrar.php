<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='venda') {
    need([1,3]);
    $cart=[];
    foreach($_POST['produto']??[] as $i=>$id) {
        if(!$id)continue;
        $id=positive($id);
        $cart[$id]=($cart[$id]??0)+positive($_POST['quantidade'][$i]);
    }
    if(!$cart)throw new Exception('Selecione produtos.');
    ksort($cart);
    $db->beginTransaction();
    $total=0;
    $items=[];
    foreach($cart as $id=>$n) {
        $pr=q('SELECT * FROM produtos WHERE id=? FOR UPDATE',[$id])->fetch();
        if(!$pr||$pr['quantidade']<$n)throw new Exception('Estoque insuficiente.');
        $total+=$pr['preco']*$n;
        $items[]=[$id,$n,$pr['preco']];
    }
    q('INSERT INTO vendas(usuario,total) VALUES(?,?)',[$me['id'],$total]);
    $vid=$db->lastInsertId();
    foreach($items as [$id,$n,$price]) {
        q('INSERT INTO itens_venda(venda,produto,quantidade,preco) VALUES(?,?,?,?)',[$vid,$id,$n,$price]);
        q('UPDATE produtos SET quantidade=quantidade-? WHERE id=?',[$n,$id]);
        q("INSERT INTO movimentacoes_estoque(produto,usuario,tipo,quantidade) VALUES(?,?,'Saída',?)",[$id,$me['id'],$n]);
    }
    $db->commit();
}
