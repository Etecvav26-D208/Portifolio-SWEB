<?php
// Configuração e entrada da aplicação.
define('GRAFICA_APP', true);
require __DIR__.'/includes/autenticacao.php';
require __DIR__.'/includes/permissoes.php';
require __DIR__.'/includes/processar.php';
if($me&&!in_array((int)$me['perfil'],$access[$p]??[],true)) {
    http_response_code(403);
    $p='inicio';
    $error='Acesso não autorizado.';
}
require __DIR__.'/includes/funcoes.php';
ob_start();
require __DIR__.'/includes/head.php';
$headHtml = ob_get_clean();
if (in_array($p, ['pedidos','novo_pedido'], true)) {
    $headHtml = str_replace('</head>', '<link rel="stylesheet" href="css/pedidos.css?v=1"></head>', $headHtml);
}
echo $headHtml;
if(!$me) {
    require __DIR__.'/pages/login.php';
    echo '</body></html>';
    exit;
}
require __DIR__.'/includes/header.php';
$paginas=['categorias'=>'categorias/listar.php','inicio'=>'inicio.php','funcionarios'=>'funcionarios/listar.php','produtos'=>'produtos/listar.php','estoque'=>'estoque/consultar.php','movimentos'=>'estoque/movimentar.php','vendas'=>'vendas/listar.php','novo_pedido'=>'pedidos/formulario.php','pedidos'=>'pedidos/listar.php','relatorios'=>'relatorios/listar.php'];
require __DIR__.'/pages/'.$paginas[$p];
require __DIR__.'/includes/footer.php';
