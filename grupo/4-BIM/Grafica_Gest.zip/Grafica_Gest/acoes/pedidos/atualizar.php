<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='status') {
    need([1,2,4]);
    if(!in_array($_POST['status'],['Pendente','Em produção','Concluído','Entregue']))throw new Exception('Status inválido.');
    q('UPDATE pedidos SET status=? WHERE id=?',[$_POST['status'],positive($_POST['id'])]);
}
