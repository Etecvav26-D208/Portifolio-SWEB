<?php
if (!defined('GRAFICA_APP')) exit;
$itens = rows('SELECT nome, categoria, quantidade, minimo FROM produtos ORDER BY nome');
?>
<div class="cards">
<section><small>Produtos cadastrados</small><h2><?= count($itens) ?></h2></section>
<section><small>Precisam de reposição</small><h2><?= count(array_filter($itens, fn($r) => (int)$r['quantidade'] < (int)$r['minimo'])) ?></h2></section>
</div>
<section><h2>Materiais disponíveis</h2>
<?php if (!$itens): ?><p>Nenhum produto cadastrado ainda.</p><?php endif; ?>
<?php foreach ($itens as $item): ?>
<div class="line"><div><b><?= h($item['nome']) ?></b><small><?= h($item['categoria']) ?></small></div><span><?= h($item['quantidade']) ?> unidades</span><span class="<?= (int)$item['quantidade'] < (int)$item['minimo'] ? 'alert' : 'pill' ?>"><?= (int)$item['quantidade'] < (int)$item['minimo'] ? 'Repor estoque' : 'Disponível' ?></span></div>
<?php endforeach; ?>
</section>
