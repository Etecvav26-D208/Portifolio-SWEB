<?php
if (!defined('GRAFICA_APP')) exit;
require __DIR__.'/formulario.php';
$historico = rows('SELECT p.nome,m.tipo,m.quantidade,m.data,u.nome AS responsavel FROM movimentacoes_estoque m JOIN produtos p ON p.id=m.produto JOIN usuarios u ON u.id=m.usuario ORDER BY m.id DESC');
?>
<section><h2>Histórico de movimentações</h2><p>Entradas, saídas e baixas realizadas nas vendas.</p>
<?php if (!$historico): ?><p>Ainda não há movimentações.</p><?php endif; ?>
<?php table(['Produto','Tipo','Quantidade','Data','Responsável'], $historico); ?>
</section>
