<?php
// Componente compartilhado do sistema.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
 ?>
<aside class="sidebar">
    <a class="brand" href="?p=inicio"><img src="assets/simbolo-vav.jpg" alt="Símbolo VAV"><span>gráfica<span class="brand-red">.vav</span><small>ETEC • Gestão escolar</small></span></a>
    <nav aria-label="Menu principal">
        <?php foreach (['ESPAÇO DE TRABALHO'=>['inicio','pedidos','vendas'],'MATERIAIS'=>['produtos','categorias','estoque','movimentos'],'ADMINISTRAÇÃO'=>['relatorios','funcionarios']] as $grupo=>$links): ?>
            <?php $visiveis=array_filter($links, fn($k)=>in_array((int)$me['perfil'],$access[$k],true)); if (!$visiveis) continue; ?>
            <small class="nav-group"><?=h($grupo)?></small>
            <?php foreach($visiveis as $k): ?>
                <a class="<?=$p===$k?'active':''?>" href="?p=<?=h($k)?>" <?=$p===$k?'aria-current="page"':''?>><?=menuicon($k)?><?=h($menus[$k])?></a>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </nav>
    <div class="bottom"><strong><?=h($me['nome'])?></strong><small><?=h(val('SELECT nome FROM perfis WHERE id=?',[$me['perfil']]))?></small><?php start('logout'); endform('Sair da conta'); ?></div>
</aside>
<main class="workspace page-<?=h($p)?>">
    <header><div><small>GRÁFICA VAV / <?=h($menus[$p])?></small><h1><?=h($menus[$p])?></h1></div><div class="header-date"><span class="pill">Sistema interno</span><small><?=date('d/m/Y')?></small></div></header>
<?php
if($error)echo '<div class="error">'.h($error).'</div>';
if(isset($_SESSION['flash'])) {
    echo '<div class="success">'.h($_SESSION['flash']).'</div>';
    unset($_SESSION['flash']);
}
 ?>
