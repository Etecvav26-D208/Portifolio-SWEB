<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='estoque') {
    need([1,2]);
    $n=positive($_POST['quantidade']);
    $id=positive($_POST['produto']);
    $tipo=$_POST['tipo'];
    if(!in_array($tipo,['Entrada','Saída']))throw new Exception('Tipo inválido.');
    $db->beginTransaction();
    $pr=q('SELECT * FROM produtos WHERE id=? FOR UPDATE',[$id])->fetch();
    if(!$pr)throw new Exception('Produto inválido.');
    $delta=$tipo==='Entrada'?$n:-$n;
    if($pr['quantidade']+$delta<0)throw new Exception('Estoque insuficiente.');
    q('UPDATE produtos SET quantidade=quantidade+? WHERE id=?',[$delta,$id]);
    q('INSERT INTO movimentacoes_estoque(produto,usuario,tipo,quantidade) VALUES(?,?,?,?)',[$id,$me['id'],$tipo,$n]);
    $db->commit();
}
