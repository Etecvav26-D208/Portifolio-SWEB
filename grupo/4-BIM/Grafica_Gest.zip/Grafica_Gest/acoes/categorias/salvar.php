<?php
if (!defined('GRAFICA_APP')) exit;
need([1,2]);
$nome = trim($_POST['nome'] ?? '');
if ($nome === '' || strlen($nome)>100) throw new Exception('Informe um nome válido.');
if (val('SELECT COUNT(*) FROM categorias WHERE nome=?',[$nome])) throw new Exception('Esta categoria já existe.');
q('INSERT INTO categorias(nome) VALUES(?)',[$nome]);
