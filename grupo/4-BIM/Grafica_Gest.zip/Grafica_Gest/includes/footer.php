<?php
// Componente compartilhado do sistema.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
 ?>
<footer>Gráfica VAV · Projeto acadêmico de Sistemas Web · ETEC Vasco Antônio Venchiarutti</footer></main><script src="js/script.js"></script></body></html>
