<?php
if (!defined('GRAFICA_APP')) exit;
$categorias = rows('SELECT c.nome, COUNT(p.id) AS produtos FROM categorias c LEFT JOIN produtos p ON p.categoria=c.nome GROUP BY c.id,c.nome ORDER BY c.nome');
?>
<section>
    <h2>Nova categoria</h2>
    <p>Crie grupos como Papelaria, Impressão ou Personalizados.</p>
    <?php start('categoria'); ?>
    <?php field('Nome da categoria','nome','text','','required maxlength="100"'); ?>
    <?php endform('Criar categoria'); ?>
</section>
<section>
    <h2>Categorias cadastradas</h2>
    <?php if (!$categorias): ?><p>Nenhuma categoria cadastrada.</p><?php endif; ?>
    <?php table(['Categoria','Produtos vinculados'],$categorias); ?>
</section>
