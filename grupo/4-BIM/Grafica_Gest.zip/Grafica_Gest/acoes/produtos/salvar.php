<?php
// Processamento da operação e validação dos dados.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
if($a==='produto') {
    need([1,2]);
    $d=[trim($_POST['nome']),trim($_POST['categoria']),trim($_POST['descricao']),amount($_POST['preco']),positive($_POST['minimo'])];
    if(!val('SELECT COUNT(*) FROM categorias WHERE nome=?',[$d[1]])) throw new Exception('Selecione uma categoria cadastrada.');
    if(!$d[0])throw new Exception('Informe o nome.');
    $id=(int)($_POST['id']??0);
    if($id)q('UPDATE produtos SET nome=?,categoria=?,descricao=?,preco=?,minimo=? WHERE id=?',[...$d,$id]);
    else q('INSERT INTO produtos(nome,categoria,descricao,preco,minimo) VALUES(?,?,?,?,?)',$d);
}
