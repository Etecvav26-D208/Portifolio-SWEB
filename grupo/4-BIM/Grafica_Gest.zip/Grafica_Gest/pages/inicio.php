<?php
// Tela do sistema: apresentação dos dados e formulários.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
 ?>
<div class="dashboard-top"><section class="banner"><div class="banner-copy"><small>01 / ESPAÇO CRIATIVO</small><h2>Ideias no papel.<br>Gestão em dia.</h2><p>Olá, <?=h($me['nome'])?>! Bem-vindo à gráfica da VAV.</p><?php if(in_array((int)$me['perfil'],$access['pedidos'],true)): ?><a class="hero-link" href="?p=pedidos">Ver pedidos gráficos →</a><?php endif; ?></div></section><section class="campus"><img src="assets/escola.jpg" alt="Entrada da ETEC VAV"><div><small> NOSSA ESCOLA</small><strong>Vasco Antônio Venchiarutti</strong><small>Foto: Jornal da Região</small></div></section></div><div class="cards">
<?php
$metrics=match((int)$me['perfil']) {
    1=>['Vendas'=>money(val('SELECT COALESCE(SUM(total),0) FROM vendas')),'Pedidos'=>val('SELECT COUNT(*) FROM pedidos'),'Produtos'=>val('SELECT COUNT(*) FROM produtos'),'Estoque baixo'=>val('SELECT COUNT(*) FROM produtos WHERE quantidade<minimo')],2=>['Vendas'=>money(val('SELECT COALESCE(SUM(total),0) FROM vendas')),'Pedidos'=>val('SELECT COUNT(*) FROM pedidos'),'Estoque baixo'=>val('SELECT COUNT(*) FROM produtos WHERE quantidade<minimo')],3=>['Produtos'=>val('SELECT COUNT(*) FROM produtos'),'Minhas vendas'=>val('SELECT COUNT(*) FROM vendas WHERE usuario=?',[$me['id']])],4=>['Pedidos pendentes'=>val("SELECT COUNT(*) FROM pedidos WHERE status='Pendente'"),'Em produção'=>val("SELECT COUNT(*) FROM pedidos WHERE status='Em produção'")]
}
;
foreach($metrics as $k=>$v)echo '<section><small>'.h($k).'</small><h2>'.h($v).'</h2></section>';
 ?>
</div><section class="modules"><small>02 / FERRAMENTAS</small><h2>Seu espaço de trabalho</h2><div class="quick">
<?php
foreach($menus as $k=>$v)if($k!=='inicio'&&in_array((int)$me['perfil'],$access[$k],true))echo '<a class="tile-'.$k.'" href="?p='.$k.'">'.menuicon($k).'<strong>'.h($v).'</strong><small>'.h($descriptions[$k]).'</small><span class="arrow">↗</span></a>';
 ?>
</div></section>
