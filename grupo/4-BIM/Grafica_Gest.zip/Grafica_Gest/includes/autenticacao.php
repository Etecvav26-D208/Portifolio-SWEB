<?php
// Componente compartilhado do sistema.
if (!defined('GRAFICA_APP'))  {
    http_response_code(403);
    exit('Acesso restrito.');
}
session_start();
require __DIR__.'/../config/conexao.php';
function h($s) {
    return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');
}
function money($n) {
    return 'R$ '.number_format($n,2,',','.');
}
try {
    $db=new PDO("mysql:host=$host;dbname=$banco;charset=utf8mb4",$usuario,$senha,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
}
catch(Throwable $e) {
    exit('Importe banco.sql no phpMyAdmin e confira config/conexao.php.');
}
function q($sql,$p=[]) {
    global $db;
    $s=$db->prepare($sql);
    $s->execute($p);
    return $s;
}
function rows($sql,$p=[]) {
    return q($sql,$p)->fetchAll(PDO::FETCH_ASSOC);
}
function val($sql,$p=[]) {
    return q($sql,$p)->fetchColumn();
}
function go($p='inicio') {
    header('Location: ?p='.$p);
    exit;
}
// Verifica as permissões do funcionário
function need(array $roles): void {
    global $me;

    if (!is_array($me) || !isset($me['perfil'])) {
        throw new Exception('Usuário não autenticado.');
    }

    if (!in_array((int)$me['perfil'], $roles, true)) {
        throw new Exception('Acesso não autorizado.');
    }
}
function positive($v) {
    if(filter_var($v,FILTER_VALIDATE_INT)===false||$v<1)throw new Exception('Quantidade inválida.');
    return (int)$v;
}
function amount($v) {
    if(!is_numeric($v)||$v<0||$v>99999999)throw new Exception('Valor inválido.');
    return $v;
}
$_SESSION['csrf']??=bin2hex(random_bytes(32));
$error='';
$me=null;
if(isset($_SESSION['uid']))$me=q('SELECT * FROM usuarios WHERE id=? AND ativo=1',[$_SESSION['uid']])->fetch(PDO::FETCH_ASSOC);
$setup=!val('SELECT COUNT(*) FROM usuarios');
