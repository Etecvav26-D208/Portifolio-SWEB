<?php
if (!defined('GRAFICA_APP')) {
    http_response_code(403);
    exit('Acesso restrito.');
}
?>
<main class="login login-vav">
    <section class="loginform">
        <div class="login-identidade">
            <img src="assets/simbolo-vav.jpg" alt="Símbolo da ETEC VAV">
            <strong>gráfica<span>.vav</span></strong>
            <small>ETEC Vasco Antônio Venchiarutti</small>
        </div>
        <div class="login-divider"></div>
        <small>PORTAL DE GESTÃO ESCOLAR</small>
        <h2><?= $setup ? 'Configuração inicial' : 'Bem-vindo!' ?></h2>
        <p><?= $setup ? 'Crie a primeira conta de administrador.' : 'Acesse sua conta para continuar.' ?></p>
        <?php
        if ($error) {
            echo '<div class="error">' . h($error) . '</div>';
        }
        start($setup ? 'setup' : 'login');
        if ($setup) {
            field('Nome', 'nome');
        }
        field('Usuário', 'login');
        field('Senha', 'senha', 'password');
        endform($setup ? 'Criar administrador' : 'Entrar no sistema');
        ?>
        <div class="login-nota">Gráfica VAV · Acesso interno</div>
    </section>
</main>
