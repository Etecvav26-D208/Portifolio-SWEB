<?php
// Consulta local: o formulário não depende de uma variável de outra página.
if (!defined('GRAFICA_APP')) {
    http_response_code(403);
    exit;
}
$produtosEstoque = rows('SELECT id, nome FROM produtos ORDER BY nome');
?>
<section>
    <h2>Movimentar estoque</h2>
    <?php if (!$produtosEstoque): ?>
        <p>Cadastre um produto antes de movimentar o estoque.</p>
    <?php else: ?>
        <?php start('estoque'); ?>
        <label>Produto
            <select name="produto" required>
                <?php foreach ($produtosEstoque as $produto): ?>
                    <option value="<?= h($produto['id']) ?>"><?= h($produto['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Tipo
            <select name="tipo">
                <option>Entrada</option>
                <option>Saída</option>
            </select>
        </label>
        <?php field('Quantidade', 'quantidade', 'number', '', 'required min="1"'); ?>
        <?php endform('Registrar movimento'); ?>
    <?php endif; ?>
</section>
